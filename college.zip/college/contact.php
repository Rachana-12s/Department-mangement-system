<?php include('dbCon.php');?>
<div class="container-fluid">
    <div class="row">
    
    <div class="col-sm-10">
        <div class="panel panel-default">
        <div class="panel-body">

	<center><h1 style="color: #4e198a">Department of Artificial Intelligence and Machine Learning</h1></center>
    	<hr>

	    <div class="text-box">
            <p style="color: #4e198a">5th Floor, Visvesvaraya Block<br>
            NMAM Institute of Technology<br>
            Nitte - 574110, Karkala<br>
            Udupi, Karnataka<br>
            Tel: +91 8258 281039<br>
            E-mail: aimldeptoffice@nmamit.in<br>
            <a href=https://nmamit.nitte.edu.in/department-AI&ML.php>Website</a><br>
            </p>
	    </div>
	</div>
	</div>
    </div>
    </div>
</div>