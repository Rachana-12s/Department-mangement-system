<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIML</title>
    <link rel = "stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
</head>
<body>
    <section class="header">
        <nav>
            <a href="index.html"><img src="Images/logo.png"></a>
            <div class = "nav-links" id="navLinks">
                <i class="fa fa-times" onclick="hideMenu()"></i>
                <ul>
                    <li><a href="index.php">HOME</a></li>
		    <li><a href="login.php">LOGIN</a></li>
                    <li><a href="">ABOUT</a></li>
                    <li><a href="">COURSES</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
        </nav>
    <div class = "text-box">
        <h1>Department of Artificial Intelligence and Machine Learning</h1>
        <p>“Some people call this artificial intelligence, but the reality is this technology will enhance us. So instead of artificial intelligence, I think we'll augment our intelligence.” —Ginni Rometty
        </p>
        <a href="https://nmamit.nitte.edu.in/department-AI&ML.php#Overview" class="hero-btn">Visit us to know more</a>
    </div>
    </section>

    <!------ Course ------>
    <section class = "course">
        <h1>Courses</h1>
        <p>Courses offered in different years</p>
        <div class="row">
            <div class="course-col">
                <h3>2nd Year</h3>
                <p>All the fundamentals of AI and ML</p>
            </div>
            <div class="course-col">
                <h3>3rd Year</h3>
                <p>Advancement of AI and ML</p>
            </div>
            <div class="course-col">
                <h3>4th Year</h3>
                <p>Preparation and ready for placements AI and ML</p>
            </div>
        </div>
    </section>

    <!----- Campus----->
    <section class = "campus">
        <h1>About Us</h1>
        <p>We are a global community ...</p>
        <div class="row">
            <div class="campus-col">
                <img src="Images/london.png">
                <div class="layer">
                    <h3>LEARN</h3>
                </div>
            </div>
            <div class="campus-col">
                <img src="Images/washington.png">
                <div class="layer">
                    <h3>INNOVATE</h3>
                </div>
            </div>
            <div class="campus-col">
                <img src="Images/newyork.png">
                <div class="layer">
                    <h3>INSPIRE</h3>
                </div>
            </div>
        </div>
    </section>
<!---- Faculties---->
    <section class="faculty">
        <h1>Our Faculty</h1>
        <p>Driven and Motivated</p>
        <div class="row">
            <div class="faculty-col">
                <img src="Images/basketball.jpg">
                <h3>Head of Department</h3>
            </div>
            <div class="faculty-col">
                <img src="Images/sudeshsir.jpg">
                <h3>Asst Professor</h3>
            </div>
            <div class="faculty-col">
                <img src="Images/disha.jpg">
                <h3>Asst Professor</h3>
            </div>
        </div>
    </section>

    <!----testimonials---->
    <section class="testimonials">
        <h1>What Our Student Say</h1>
        <p>We are a global community ...</p>
        <div class="row">
            <div class="testimonials-col">
                <img src="Images/user1.jpg">
                <div>
                    <p>
                        This college has provided way more than i could imagine
                    </p>
                    <h3>Someone</h3>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-regular fa-star"></i>
                </div>
            </div>
            <div class="testimonials-col">
                <img src="Images/user2.jpg">
                <div>
                    <p>
                        This college has provided way more than i could imagine
                    </p>
                    <h3>Someone2</h3>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star-half-stroke"></i>
                </div>
            </div>
        </div>
    </section>
    <!-- Display Student Count -->
<section class="student-count">
    <h1>Student Count</h1>
    <div class="row">
        <div class="student-count-col">
            <p>Total Students:</p>
            <?php
            // Your database connection code goes here

            $servername = "127.0.0.1";
            $username = "root";
            $password = "";
            $dbname = "aiml";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT COUNT(*) as total_students FROM student";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $totalStudents = $row["total_students"];
                echo "<span class='count'>$totalStudents</span>";
            } else {
                echo "0";
            }

            $conn->close();
            ?>
        </div>
    </div>
</section>

    
    
    <!------ Call to Action ------>
    <section class="cta">
        <h1>Enroll for our course</h1>
        <a href="contact.php" class="hero-btn">CONTACT US</a>
    </section>

    <!------ Footer ------>
    <section class="footer">
        <h4>About Us</h4>
        <p>About us ... we are strongly .....</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-linkedin"></i>
        </div>
        <p>Madee with <i class="fa fa-heart-o"></i> Easy Tutorials</p>
    </section>


<!------JavaScript for Toggle Menu ------>
<script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    }
    function hideMenu(){
        navLinks.style.right = "-200px";
    }
</script>
</body>
</html>